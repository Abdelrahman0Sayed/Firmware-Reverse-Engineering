const { app, BrowserWindow, ipcMain } = require('electron');
const path = require('path');
const { spawn } = require('child_process');

let mainWindow;
let mcpProcess = null;
let mcpStdin = null;
let mcpStdout = null;
let requestId = 0;
let pendingRequests = new Map();

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1200,
    height: 800,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      preload: path.join(__dirname, 'preload.cjs')
    },
    backgroundColor: '#1e1e1e',
    title: 'Ghidra Decompiler'
  });

  mainWindow.loadFile('index.html');

  // Open DevTools in development mode
  if (process.argv.includes('--dev')) {
    mainWindow.webContents.openDevTools();
  }
}

app.whenReady().then(createWindow);

app.on('window-all-closed', () => {
  if (mcpProcess) {
    mcpProcess.kill();
  }
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) {
    createWindow();
  }
});

// Helper function to send JSON-RPC message
function sendMCPMessage(method, params = {}) {
  return new Promise((resolve, reject) => {
    if (!mcpProcess || !mcpStdin) {
      reject(new Error('Not connected to MCP server'));
      return;
    }

    const id = ++requestId;
    const message = JSON.stringify({
      jsonrpc: '2.0',
      id,
      method,
      params
    });

    pendingRequests.set(id, { resolve, reject });

    try {
      mcpStdin.write(message + '\n');
    } catch (error) {
      pendingRequests.delete(id);
      reject(error);
    }

    // Timeout after 30 seconds
    setTimeout(() => {
      if (pendingRequests.has(id)) {
        pendingRequests.delete(id);
        reject(new Error('Request timeout'));
      }
    }, 30000);
  });
}

// Handle MCP connection
ipcMain.handle('connect-mcp', async (event, config) => {
  try {
    // Kill existing process if any
    if (mcpProcess) {
      mcpProcess.kill();
      mcpProcess = null;
    }

    // Clear pending requests
    pendingRequests.clear();
    requestId = 0;

    // Spawn the MCP server process
    const command = config.command || 'ghidra-mcp';
    const args = config.args || [];

    mcpProcess = spawn(command, args, {
      stdio: ['pipe', 'pipe', 'pipe']
    });

    mcpStdin = mcpProcess.stdin;
    mcpStdout = mcpProcess.stdout;

    let buffer = '';

    // Handle stdout data
    mcpStdout.on('data', (data) => {
      buffer += data.toString();
      const lines = buffer.split('\n');
      buffer = lines.pop(); // Keep incomplete line in buffer

      for (const line of lines) {
        if (line.trim()) {
          try {
            const response = JSON.parse(line);
            
            if (response.id && pendingRequests.has(response.id)) {
              const { resolve, reject } = pendingRequests.get(response.id);
              pendingRequests.delete(response.id);

              if (response.error) {
                reject(new Error(response.error.message || 'MCP error'));
              } else {
                resolve(response.result);
              }
            }
          } catch (error) {
            console.error('Failed to parse MCP response:', error, line);
          }
        }
      }
    });

    // Handle stderr
    mcpProcess.stderr.on('data', (data) => {
      console.error('MCP stderr:', data.toString());
    });

    // Handle process exit
    mcpProcess.on('exit', (code) => {
      console.log('MCP process exited with code:', code);
      mcpProcess = null;
      mcpStdin = null;
      mcpStdout = null;
      
      // Reject all pending requests
      for (const [id, { reject }] of pendingRequests) {
        reject(new Error('MCP server disconnected'));
      }
      pendingRequests.clear();
    });

    // Send initialize request
    await sendMCPMessage('initialize', {
      protocolVersion: '2024-11-05',
      capabilities: {},
      clientInfo: {
        name: 'ghidra-decompiler',
        version: '1.0.0'
      }
    });

    // Send initialized notification
    mcpStdin.write(JSON.stringify({
      jsonrpc: '2.0',
      method: 'notifications/initialized'
    }) + '\n');

    return { success: true, message: 'Connected to GhidraMCP' };
  } catch (error) {
    console.error('MCP connection error:', error);
    if (mcpProcess) {
      mcpProcess.kill();
      mcpProcess = null;
    }
    return { success: false, message: error.message };
  }
});

// Handle decompilation request
ipcMain.handle('decompile', async (event, { assembly, architecture, baseAddress }) => {
  try {
    if (!mcpProcess) {
      throw new Error('Not connected to MCP server');
    }

    // Call the decompile tool
    const result = await sendMCPMessage('tools/call', {
      name: 'decompile',
      arguments: {
        assembly_code: assembly,
        architecture: architecture || 'x86:LE:64:default',
        base_address: baseAddress || '0x100000'
      }
    });

    // Extract text from content array
    let cCode = '';
    if (result.content && Array.isArray(result.content)) {
      cCode = result.content
        .filter(item => item.type === 'text')
        .map(item => item.text)
        .join('\n');
    } else if (typeof result === 'string') {
      cCode = result;
    } else {
      cCode = JSON.stringify(result, null, 2);
    }

    return {
      success: true,
      cCode,
      metadata: {
        architecture,
        baseAddress
      }
    };
  } catch (error) {
    console.error('Decompilation error:', error);
    return {
      success: false,
      error: error.message
    };
  }
});

// Get available tools from MCP
ipcMain.handle('get-tools', async () => {
  try {
    if (!mcpProcess) {
      throw new Error('Not connected to MCP server');
    }

    const result = await sendMCPMessage('tools/list');
    
    return {
      success: true,
      tools: result.tools || []
    };
  } catch (error) {
    return {
      success: false,
      error: error.message
    };
  }
});

// Disconnect from MCP
ipcMain.handle('disconnect-mcp', async () => {
  try {
    if (mcpProcess) {
      mcpProcess.kill();
      mcpProcess = null;
      mcpStdin = null;
      mcpStdout = null;
    }
    pendingRequests.clear();
    return { success: true };
  } catch (error) {
    return { success: false, error: error.message };
  }
});
